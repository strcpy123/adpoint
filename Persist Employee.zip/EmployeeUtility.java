import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class EmployeeUtility {
	boolean exits = false;

	public boolean addEmployee(String fileName, ArrayList<Employee> employeeList) {
		try {
			FileOutputStream file = new FileOutputStream(fileName);
			ObjectOutputStream out = new ObjectOutputStream(file);

			out.writeObject(employeeList);
			exits = true;
			out.close();
			file.close();

		}

		catch (IOException ex) {
			exits = false;
			System.out.println("IOException is caught");

		}
		return exits;
	}

	public Employee viewEmployeeById(String fileName, int employeeId) {
		List<Employee> list1 = null;
		Employee emp = null;
		try {
			FileInputStream file = new FileInputStream(fileName);
			ObjectInputStream in = new ObjectInputStream(file);
			list1=(ArrayList<Employee>)in.readObject();
			in.close();
			file.close();
		}

		catch (IOException ex) {
			System.out.println("IOException is caught");
			System.exit(0);
		}

		catch (ClassNotFoundException ex) {
			System.out.println("ClassNotFoundException is caught");
			System.exit(0);
		}
		for (int i = 0; i < list1.size(); i++) {
			if (list1.get(i).getEmployeeId() == employeeId)
				emp=list1.get(i);
		}
		return emp;
		
	}
}
