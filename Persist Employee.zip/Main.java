public class Main{
    public static void main(String args[]){
		// List<Employee> list = new ArrayList<Employee>();
		// Scanner in = new Scanner(System.in);
		// EmployeeUtility util = new EmployeeUtility();
		// System.out.println("Enter employeeid");
		// int id = in.nextInt();
		// in.nextLine();
		// System.out.println("Enter name");
		// String name = in.nextLine();
		// System.out.println("Enter AppraisalRating");
		// float appraisalRating = in.nextFloat();
		// Employee emp = new Employee(id,name,appraisalRating);
		// list.add(emp);
		// util.addEmployee("C:/Users/842094/workspace/cogRainfall/src/AllCityMonthlyRainfall.txt",
		// (ArrayList<Employee>) list);
        
    }
}